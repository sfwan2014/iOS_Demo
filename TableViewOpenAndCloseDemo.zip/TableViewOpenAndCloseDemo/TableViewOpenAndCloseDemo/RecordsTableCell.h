//
//  RecordsTableCell.h
//  TableViewOpenAndCloseDemo
//
//  Created by sfwan on 14-12-12.
//  Copyright (c) 2014年 MIDUO. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIViewExt.h"
#import "RecordsModel.h"
@interface RecordsTableCell : UITableViewCell
@property (nonatomic, strong) RecordsModel *model;
@end
