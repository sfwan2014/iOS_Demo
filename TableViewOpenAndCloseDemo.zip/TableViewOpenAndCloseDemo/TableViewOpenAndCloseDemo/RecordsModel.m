//
//  RecordsModel.m
//  安心贷
//
//  Created by sfwan on 14-12-11.
//  Copyright (c) 2014年 xing.peng. All rights reserved.
//

#import "RecordsModel.h"

@implementation RecordsModel

@end
